
# Addon is a fork of a known addon on kodi


# -*- coding: utf-8 -*-

from resources.lib import plugin

plugin.run()



